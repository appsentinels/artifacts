#!/bin/bash
export HOSTNAME="appsentinels-poc-aks.appsentinels.ai"
export LOADBALANCER_IP="4.224.65.227"
export POSTGRES_HOST="db"
export NFS_SERVER_IP="10.191.253.2"
export NFS_PATH="/data"
# Set to "azure" or "gcp" or leave it empty
export CLOUD_PROVIDER="azure"
# Set to "true" to enable local db service or "false"
export LOCAL_DB_SERVICE_ENABLED="true"
## Image repository where the image get pulled for each services for eg (docker.io/appsentinelsai/adminapp:main-latest)
export IMAGE_REGISTRY="docker.io/appsentinelsai"
### Image registry to download image based on username & password (token)
export IMAGE_REPO_USERNAME="appsentinelsai"
## Image repo url to create secrets for secure login
export IMAGE_REPO_SERVER="https://index.docker.io/v1/"