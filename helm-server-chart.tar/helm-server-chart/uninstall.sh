
kubectl delete namespace appsentinels
kubectl delete -f ./storage/azure/pvc.yaml
kubectl delete -f ./storage/azure/data_storage_class.yaml
kubectl delete -f ./storage/azure/db_storage_class.yaml
