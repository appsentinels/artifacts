#!/bin/bash
set -ex
source ./variables.sh
sed "s|REPLACE_APPSENTINELS_PLATFORM|$HOSTNAME|g" ./values.yaml.template > ./.values.yaml.template.1
sed "s|REPLACE_LOADBALANCER_IP|$LOADBALANCER_IP|g" ./.values.yaml.template.1 > ./.values.yaml.template.2
sed "s|REPLACE_POSTGRES_HOST|$POSTGRES_HOST|g" ./.values.yaml.template.2 > ./.values.yaml.template.3
sed "s|REPLACE_LOCAL_DB_SERVICE_ENABLED|$LOCAL_DB_SERVICE_ENABLED|g" ./.values.yaml.template.3 > ./.values.yaml.template.4

SECURED_LOGIN_VALUE="false"
# If DOCKER_REGISTRY is set, securedDockerLogin should be true
if [ -n "$IMAGE_REPO_USERNAME" ]; then
  SECURED_LOGIN_VALUE="true"
fi
# Replace both values in a single sed command
sed -e "s|REPLACE_DOCKER_REGISTRY|$IMAGE_REGISTRY|g" \
    -e "s|securedDockerLogin: false|securedDockerLogin: $SECURED_LOGIN_VALUE|g" \
    ./.values.yaml.template.4 > ./values.yaml
set +ex