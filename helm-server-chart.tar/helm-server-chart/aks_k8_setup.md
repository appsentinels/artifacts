# Azure Kubernetes Service (AKS) Setup Guide

### 1. Creating AKS Cluster
1. Go to Azure Portal and search for "Kubernetes Service"
2. Click on "Create" and select "Kubernetes Cluster"
3. Choose the subscription and create a new resource group (in this example we will use "appsentinels-poc-rg-1")
4. Select preset as per need
5. Choose the Kubernetes cluster name. In this example we will use "appsentinels-poc-aks-1"
6. Choose region as per need
7. Choose AKS pricing tier as per need. 
8. Leave the rest of the fields as default and click on "Next"
9. In Node pools section, select "Add node pool"
10. Select the node pool name as "workers", Mode as "User". OS SKU as "Ubuntu"
11. Choose the node size as per your need. Typically any node with 8G 32GB should suffice (eg: D8s_v3).
12. Choose manual scaling (or auto if you are sure) and save
13. Do the same for "agent" node pool as well
14. Click on "Next" for Networking, Integrations and keep the default options
15. For monitoring and security, turn off any monitoring that isnt required
16. In advanced, a new infrastructure resource group will be created for the cluster. For Eg: name "MC_appsentinels-poc-rg-1_appsentinels-poc-aks-1_centralindia". Note this down
17. Add any tags and then choose Review + Create. Once validation is done, choose create. Wait for the deployment to be done. This takes about 3-5 mins
18. Once deployment is done, get the public IP address of the AKS cluster. Go to the infrastructure resource group (eg: MC_appsentinels-poc-rg-1_appsentinels-poc-aks-1_centralindia) and find the public IP address in the list of the Resources. Click on it and note down the 'IP address'. This will be used to access the AKS cluster via load balancer.
19. Please map this IP address to the DNS name of the AppSentinels server

### 2. Creating storage for cluster
1. Go to Azure Portal and search for "Storage Account"
2. Click on "Create" and select the correct subscription and resource group. This should be infrastructure resource group created for the AKS cluster (eg: MC_appsentinels-poc-rg-1_appsentinels-poc-aks-1_centralindia).
3. Choose the storage account name. In this example we will use "appsentinelspocstorage1". Note this down
4. Choose the region as per need. 
5. Choose Azure Files as the primary service
6. Choose Premium Performance for SSD. By default you can choose LRS for redundancy. If zonal redundancy is required, choose ZRS.
7. Skip past Advanced, Networking, Data Protection
8. In Encryption section
   - Choose Encryption type as Microsoft Managed Keys MMK
   - Choose "All service types" under Enable support for customer-managed keys 
9. Skip past Tags, Review + Create and click on Create. Wait for the deployment to be done. This takes about a minute or so.

### 3. Azure CLI Setup
Install azure cli and login to azure account. Switch to the this AKS cluster context using,
```bash
   az aks get-credentials --resource-group <cluster rg> --name <cluster name> --overwrite-existing

   eg: az aks get-credentials --resource-group appsentinels-poc-rg-1 --name appsentinels-poc-aks-1 --overwrite-existing
```

### 4. Certificate Setup
1. In installation package provided, navigate to `./files/certs`
2. Run `create_certificate.sh` to generate:
   - tls.key
   - tls.pem
   - tls.crt
   
Note: This script also creates a cert secret in Kubernetes

### 5. Secret Configuration
1. Navigate to `./files/secrets`
2. Update the following passwords files (make sure there are no spaces or newlines)
   - DEVOPS: Update password and set database hostname to 'db'
   - POSTGRES_PASSWORD: Use Kong user's password
3. Update IMAGE_REPO_TOKEN with password or token from docker hub setting page

### 6. Pre-Installation Configuration
1. Go back to the top level directory. Open `variables.sh` and configure:
   - HOSTNAME (of AppSentinels server)
   - LOADBALANCER_IP (public IP address of the AKS cluster, we noted from the infrastructure resource group)
   - POSTGRES_HOST, set this as just 'db'
   - NFS_SERVER_IP - leave it blank, i.e ""
   - NFS_PATH - leave it blank, i.e ""
   - CLOUD_PROVIDER - set this as 'azure'
   - LOCAL_DB_SERVICE_ENABLED - set this as 'true'
   - IMAGE_REGISTRY - Image registry to be set by default docker.io/appsentinelsai
   - IMAGE_REPO_USERNAME - provide the username for secured login
   - IMAGE_REPO_SERVER - Provide the docker hub server url for secured login
    
2. Prepare the storage class creation and persistent volume claim configuration
   - Navigate to `./storage/azure`
   - Open data_storage_class.yaml and update the storage account name
   - Open db_storage_class.yaml and update the storage account name
   - Open pvc.yaml and update the spec.resources.requests.storage as per requirement for both the claims

5. Navigate back to root directory
   - Open values.yaml.template and update any values as per requirement
   - Run `pre_installation.sh`

6. Verify secrets:
```bash
kubectl get secrets -n appsentinels
```

6. Setup Persistent Volume Claims
   - NFS configuration on Azure is done in several steps
   - Head back to Azure portal and under Storage, choose the storage account we created earlier
   - Choose Data Storage and then File shares. You should see 2 file shares created, one for db and another for data
   - For either of the File Shares (data and db), perform the below steps:
    1. Click on the file share
    2. Under "Configure from Linux" tab, choose Review options under Network configuration
    3. Choose Setup a Private Endpoint and then add Private Endpoint
    4. Under Basics, choose the infrastructure resource group, name the private endpoint as "private-endpoint" and choose the region as per need
    5. Under Virtual Network, choose Virtual Network of the AKS cluster. Choose the subnet. Keep the Private IP configuration as "Dynamic"
    6. Under DNS, choose Integrate with private DNS zone. 
    7. Finally click on Review + Create and then Create. Wait for the deployment to be done. This takes about a minute or so.
    8. Head back again to the File Share and then Under "Connect from Linux" tab, choose "Change setting" under Secure transfer setting. Disable "Secure transfer required" and then Save. Azure doesnt support security at protocol level for NFS shares, but instead performs L2 level encryption for security. 

   - Check if the PVC are created and in Bound state.
   ```bash
    kubectl get pvc -n appsentinels
    NAME         STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS
    data-claim   Bound    pvc-0a009c1f-c1b0-4c3a-aa4b-ecef38ca7a42   3Ti        RWX            data-storage
    db-claim     Bound    pvc-f44a6ad7-4680-4057-b67d-0a4ca15e3261   200Gi      RWX            db-storage  
   ```

### 7. DB bringup
```bash
helm install <release> . --set stage1.enabled=true
```
1. Verify that utils is running fine.
```bash
kubectl get pods -n appsentinels
NAME                              READY   STATUS             RESTARTS        AGE
keycloak-local-b977f4678-4xvtz    1/1     CrashLoopBackOff       0               14m
kong-5977c454cf-5bdnd             1/1     CrashLoopBackOff       0               14m
kong-migrations-fc957bc8f-sqstf   0/1     CrashLoopBackOff       7 (3m17s ago)   14m
utils-697c85575-r2lzs             1/1     Running                0               14m
```
2. 'Exec' into utils container
3. Navigate to `/kubernetes-requirements` and run directory_permission.sh. This will setup the directory permissions for the shared mounts for data and db
4. Exit the utils pod and bring them down using,
   ```bash
   helm upgrade <release> . --set stage1.enabled=false
   ```
6. Bring up the DB service now.
   ```bash
   helm upgrade <release> . --set db_setup.enabled=true
   ```
8. Verify that the db pod is running fine. First time boot of db service will take a while. Wait for a couple of minutes before proceeding
9. Exec into the db pod to create required databases and users
   ```bash
   kubectl exec -it <db-pod-name> -n appsentinels -- bash
   ```
10. Login into the postgres command line interface
   ```bash
   PGPASSWORD=<db-password> psql -h localhost -U kong 
   ```
11. Create the required databases and users
   ```bash
   CREATE USER devops SUPERUSER LOGIN encrypted password '<devops-password>';          
   create database devops;                                                            
   create database keycloak;   
   ```
   Please note the devops-password should be same as the one in the files/secrets/DEVOPS file  
11. Exit the db pod once done

### 8. Kong Configuration
1. Bring up stage1 and db together now
   ```bash
   helm upgrade <release> . --set stage1.enabled=true,db_setup.enabled=true
   ```
2. Verify that the pods are running fine.
    ```bash
    kubectl get pods -n appsentinels
    NAME                              READY   STATUS             RESTARTS        AGE
    db-75578dc7bf-l6kp6                                    1/1     Running   
    keycloak-local-7d5c9c57f8-x4m7g                        1/1     Running   
    kong-5547dbddbf-cnrrl                                  1/1     Running   
    kong-migrations-5c7675d69c-wgb7p                       0/1     Completed 
    utils-6b955c6856-dptdm                                 1/1     Running   
    ```
    You can ignore kong-migration in a reboot loop if kong is running fine.
3. 'Exec' into utils container
4. Navigate to `/kubernetes-requirements`
5. Run `./kong_config.sh` and exit
6. Verify Kong service LoadBalancer IP:
```bash
kubectl get svc -n appsentinels | grep LoadBalancer
```

### 9. Keycloak Setup
1. Wait for Keycloak to start and complete verification (~2 minutes). Ensure the server hostname is resolvable before the next step
2. Run `python3 keycloak_setup.py`
3. This will generate:
   - keycloak_user_id.txt
   - keycloak_client_secret.txt
   - keycloak.pem
4. Update auth config:
   1. Copy keycloak_client_secret.txt contents to KEYCLOAK_CLIENT_SECRET in files/secrets/AUTH_CONFIG
   2. Come back to the main directory and update the auth-config-secret
   ```bash 
   kubectl delete secret -n appsentinels auth-config-secret
   kubectl create secret generic auth-config-secret --from-file=auth_config=./files/secrets/AUTH_CONFIG -n appsentinels
   ```
5. Configure Kong JWT:
   - Copy keycloak.pem to utils `/kubernetes-requirements/`
   ```bash
   kubectl cp keycloak.pem -n appsentinels     <utils-pod-name>:/kubernetes-requirements/
   ```
   - Exec to utils, navigate to `/kubernetes-requirements/` and run `./kong_jwt.sh`
   - Exit from the utils pod and continue

### 10. Restart Cluster
1. Bring down the cluster for a clean start:
```bash
helm uninstall <release>
```
2. Bring up the cluster with both stages:
```bash
helm install <release> . --set stage2.enabled=true
```

### 11. Create users and demo organization
1. Exec into utils and navigate to `/kubernetes-requirements`
2. Run below for creating a demo org and an associated org admin `demo@appsentinels.ai`:
   ```bash
      ./default_user_org.sh 
   ```
3. Note down the API key for a demo controller
4. Restart adminapp pod,
```bash
   kubectl delete pod <adminapp pod name> -n appsentinels
```
