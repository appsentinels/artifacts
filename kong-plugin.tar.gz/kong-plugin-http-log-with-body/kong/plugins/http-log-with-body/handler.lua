local basic_serializer = require "kong.plugins.log-serializers.basic"
local body_transformer = require "kong.plugins.response-transformer.body_transformer"
local BatchQueue = require "kong.tools.batch_queue"
local cjson = require "cjson"
local url = require "socket.url"
local http = require "resty.http"

local is_json_body = body_transformer.is_json_body
local cjson_decode = cjson.decode
local cjson_encode = cjson.encode
local ngx_encode_base64 = ngx.encode_base64
local table_concat = table.concat
local fmt = string.format

local new_handler = 1

local HttpLogHandler = {}


HttpLogHandler.PRIORITY = 12
HttpLogHandler.VERSION = "0.1.1"


local queues = {} -- one queue per unique plugin config

local parsed_urls_cache = {}


-- Parse host url.
-- @param `url` host url
-- @return `parsed_url` a table with host details:
-- scheme, host, port, path, query, userinfo
local function parse_url(host_url)
  local parsed_url = parsed_urls_cache[host_url]

  if parsed_url then
    return parsed_url
  end

  parsed_url = url.parse(host_url)
  if not parsed_url.port then
    if parsed_url.scheme == "http" then
      parsed_url.port = 80
    elseif parsed_url.scheme == "https" then
      parsed_url.port = 443
    end
  end
  if not parsed_url.path then
    parsed_url.path = "/"
  end

  parsed_urls_cache[host_url] = parsed_url

  return parsed_url
end


-- Sends the provided payload (a string) to the configured plugin host
-- @return true if everything was sent correctly, falsy if error
-- @return error message if there was an error
local function send_payload(self, conf, payload)
  local method = conf.method
  local timeout = conf.timeout
  local keepalive = conf.keepalive
  local content_type = conf.content_type
  local http_endpoint = conf.http_endpoint
  local no_self_signed = conf.no_self_signed

  local ok, err
  local parsed_url = parse_url(http_endpoint)
  local host = parsed_url.host
  local port = tonumber(parsed_url.port)

  local httpc = http.new()
  httpc:set_timeout(timeout)
  ok, err = httpc:connect(host, port)
  if not ok then
    return nil, "failed to connect to " .. host .. ":" .. tostring(port) .. ": " .. err
  end

  if parsed_url.scheme == "https" then
    kong.log.err("Kong: https no_self_signed: ", no_self_signed)
    local _, err = httpc:ssl_handshake(true, host, no_self_signed) --- reuse, sni, do_not_accept-self-signed
    if err then
      return nil, "failed to do SSL handshake with " ..
                  host .. ":" .. tostring(port) .. ": " .. err
    end
  end

  local res, err = httpc:request({
    method = method,
    path = parsed_url.path,
    query = parsed_url.query,
    headers = {
      ["Host"] = parsed_url.host,
      ["Content-Type"] = content_type,
      ["Content-Length"] = #payload,
      ["Authorization"] = parsed_url.userinfo and (
        "Basic " .. ngx_encode_base64(parsed_url.userinfo)
      ),
    },
    body = payload,
  })
  if not res then
    return nil, "failed request to " .. host .. ":" .. tostring(port) .. ": " .. err
  end

  -- always read response body, even if we discard it without using it on success
  local response_body = res:read_body()
  local success = res.status < 400
  local err_msg

  if not success then
    if (response_body == nil or response_body == '') then
	response_body = "nil body"
    end
    err_msg = "request to " .. host .. ":" .. tostring(port) ..
              " returned status code " .. tostring(res.status) .. " and body " ..
              response_body
  end

  ok, err = httpc:set_keepalive(keepalive)
  if not ok then
    -- the batch might already be processed at this point, so not being able to set the keepalive
    -- will not return false (the batch might not need to be reprocessed)
    kong.log.err("failed keepalive for ", host, ":", tostring(port), ": ", err)
  end

  return success, err_msg
end


local function json_array_concat(entries)
  return "[" .. table_concat(entries, ",") .. "]"
end


local function get_queue_id(conf)
  return fmt("%s:%s:%s:%s:%s:%s",
             conf.http_endpoint,
             conf.method,
             conf.content_type,
             conf.timeout,
             conf.keepalive,
             conf.retry_count,
             conf.queue_size,
             conf.flush_timeout)
end



local function parse_body(type, data)
  if type and data and is_json_body(type) then
    return cjson_decode(data)
  end
end

local function parse_body_new(type, data)
  if unexpected_condition then error() end
    return parse_body(type, data)
end

function HttpLogHandler:access(conf)
  if is_json_body(kong.request.get_header("Content-Type")) then
    local ctx = kong.ctx.plugin;
    ctx.request_body = kong.request.get_raw_body();
  end
end

function HttpLogHandler:body_filter(conf)
  -- kong.log.err("body_filter: ", string.len(ngx.arg[1]))
  if is_json_body(kong.response.get_header("Content-Type")) then
    local ctx = kong.ctx.plugin;
    local chunk, eof = ngx.arg[1], ngx.arg[2];
    if not eof then
      ctx.response_body = (ctx.response_body or "") .. (chunk or "")
    end
  end
end



function HttpLogHandler:old_log(conf)
  local ctx = kong.ctx.plugin;
  local log_obj = basic_serializer.serialize(ngx)

  log_obj.request.body = parse_body(kong.request.get_header("Content-Type"), ctx.request_body)
  log_obj.response.body = parse_body(kong.response.get_header("Content-Type"), ctx.response_body)

  local entry = cjson_encode(log_obj)

  local queue_id = get_queue_id(conf)
  local q = queues[queue_id]
  if not q then
    -- batch_max_size <==> conf.queue_size
    local batch_max_size = conf.queue_size or 1
    local process = function(entries)
      local payload = batch_max_size == 1
                      and entries[1]
                      or  json_array_concat(entries)
      return send_payload(self, conf, payload)
    end

    local opts = {
      retry_count    = conf.retry_count,
      flush_timeout  = conf.flush_timeout,
      batch_max_size = batch_max_size,
      process_delay  = 0,
    }

    local err
    q, err = BatchQueue.new(process, opts)
    if not q then
      kong.log.err("could not create queue: ", err)
      return
    end
    queues[queue_id] = q
  end

  q:add(entry)
end

function HttpLogHandler:log(conf)
  local ctx = kong.ctx.plugin;
  local log_obj = basic_serializer.serialize(ngx)
  local req_body
  local resp_body

  if new_handler == 1 then

    -- seems for lookup case does not matter -- but for updating in log_obj it does -- this is all based on observation
    local auth = kong.request.get_header("authorization")
    if auth then
      -- kong.log.err("Kong: auth header value: ", auth)
      log_obj.request.headers["authorization"]=auth
    end
    local proxyauth = kong.request.get_header("Proxy-Authorization")
    if proxyauth then
      -- kong.log.err("Kong: proxy auth header value: ", proxyauth)
      log_obj.request.headers["proxy-authorization"]=proxyauth
    end

    local req_err, temp_req_body = pcall(parse_body_new, kong.request.get_header("Content-Type"), ctx.request_body)
    if not req_err then
      -- likely a non-json body -- binary possibly -- purposedly not handling this scenraio for requests
      kong.log.err("Kong: Failed to parse request body, possibly non-json body: ", req_err)
      log_obj.request.body = "Kong: Failed to parse request body, possibly non-json body: "
    else
      log_obj.request.body = temp_req_body
    end

    local resp_err, temp_resp_body = pcall(parse_body_new, kong.response.get_header("Content-Type"), ctx.response_body)
    if not resp_err then
      log_obj.response.headers["sentinel-body"] = ngx_encode_base64(ctx.response_body)
      log_obj.response.headers["sentinel-body-decoded-len"] = tostring(string.len(ctx.response_body))
      kong.log.err("Kong: Failed to parse response body, possibly non-json body: ", resp_err, " : content len: ", string.len(ctx.response_body), " : encoded content len: ", string.len(log_obj.response.headers["sentinel-body"]))
    else
      log_obj.response.body = temp_resp_body
    end

    local entry = cjson_encode(log_obj)

    local queue_id = get_queue_id(conf)
    local q = queues[queue_id]
    if not q then
      -- batch_max_size <==> conf.queue_size
      local batch_max_size = conf.queue_size or 1
      local process = function(entries)
        local payload = batch_max_size == 1
                      and entries[1]
                      or  json_array_concat(entries)
        return send_payload(self, conf, payload)
      end

      local opts = {
        retry_count    = conf.retry_count,
        flush_timeout  = conf.flush_timeout,
        batch_max_size = batch_max_size,
        process_delay  = 0,
      } 
      local err
      q, err = BatchQueue.new(process, opts)
      if not q then
        kong.log.err("could not create queue: ", err)
        return
      end
      queues[queue_id] = q
    end
    q:add(entry)
  else
    self.log_old(conf)
  end
end

return HttpLogHandler
