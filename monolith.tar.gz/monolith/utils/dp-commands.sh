#!/bin/bash

default_port="9101"
default_ip="127.0.0.1"
typeset -A command_string

command_string[dp-debugstats]=dp-debugstats
command_string[dp-debugstatsclear]=dp-debugstatsclear
command_string[dp-debugdump]=dp-debugdump
command_string[dp-piicacheclear]=dp-piicacheclear
command_string[dp-logconfig]=dp-logconfig
command_string[dp-systemconfig]=dp-systemconfig
command_string[dp-status]=dp-status
command_string[dp-softrestart]=dp-softrestart
command_string[dp-apistats]=dp-apistats
command_string[dp-apistats-enable]=dp-apistats-enable
command_string[dp-remotestatsdump]=dp-remotestatsdump

Usage () {
  echo "$0 <command-name>"
  echo "Following commands are supported: "
  echo ${!command_string[@]}
  echo "Run as dp_commands <command-name> <arg>"
  exit
}

if [ $# -lt 1 ]
then
  Usage
fi

command=$1

if [ "$command" = "-h" ]; then
  Usage
fi

command_uri=${command_string[$command]}

if test -z "$command_uri" 
then
  command_uri=$command
fi

if [ "dp-logconfig" == "$command_uri" ]
then
  loglevel="error"
  if [ $# -gt 1 ]
  then
    loglevel="$2"
  fi
  echo "dp-logconfig <\"trace\"/\"error\"/\"debug\">"
  if [ "$loglevel" == "trace" ]
  then
  	curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json' -d '{"data": {"level": "trace"}}'
  elif [ "$loglevel" == "error" ]
  then
  	curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json' -d '{"data": {"level": "error"}}'
  elif [ "$loglevel" == "debug" ]
  then
  	curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json' -d '{"data": {"level": "debug"}}'
  fi
  #echo $command_str
  #curl -v $command_str
elif [ "dp-apistats-enable" == "$command_uri" ]
then
  enable="false"
  if [ $# -gt 1 ]
  then
    enable="$2"
  fi
  echo "dp-apistats-enable <\"true\"/\"false\">"
  if [ "$enable" == "true" ]
  then
  	curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json' -d '{"enable": "true"}'
  else
  	curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json' -d '{"enable": "false"}'
  fi
else
  curl $default_ip:$default_port/$command_uri -X POST  -H 'Content-type: application/json'
fi
echo
