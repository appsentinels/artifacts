#!/bin/bash

Usage () {
  echo "sudo $0 -f"
  echo "This will disable apport and sets core pattern to /var/crash/core.%e.%p.%h.%t."
  echo "use -f option to avoid running it accidently"
  exit
}

if [ $total_params -lt 2 ]
then
  Usage
fi

if [ "$1" != "-f" ]; then
  Usage
fi

echo "Stopping apport"
sudo systemctl stop apport
echo "Disabling apport  to avoid restart on reboot"
sudo systemctl disable apport.service
echo "Setting core pattern to /var/crash/core.%e.%p.%h.%t"
sudo bash -c 'echo /var/crash/core.%e.%p.%h.%t > /proc/sys/kernel/core_pattern'
