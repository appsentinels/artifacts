#!/bin/bash

echo "Steps to configure rsyslog and log rotate:"

sudo cat > /etc/logrotate.d/docker << ENDL
/var/log/appsentinels/*.log {
  daily
  rotate 10
  missingok
  dateformat -%H:%M:%S_%d%m%Y
  delaycompress
  compress
  notifempty
  create
}
ENDL

sudo cat > /etc/rsyslog.d/40-onpremcontroller.conf << ENDL
\$template CUSTOM_LOGS,"/var/log/appsentinels/%programname%.log"

if \$programname startswith 'appsentinels-' then ?CUSTOM_LOGS
& ~
ENDL

sudo mkdir -p /var/log/appsentinels
#actually it required for group syslog, the files created with user syslog group adm so can be chmod syslog:adm /var/log/appsentinels
sudo chmod go=+rwx /var/log/appsentinels
sudo systemctl restart rsyslog

