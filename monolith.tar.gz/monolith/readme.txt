Deployment steps for monolith applications or Envoy as api-gw or proxy
----------------------------------------------------------------------
This deployment serves the case where the appsentinels inspection and authorization engines are placed infront of a monolith application/service

Requirements
============
Retrieving the files locally
----------------------------

1. steps to get the docker images for envoy (front-proxy) and the controller - Not needed
docker login  --username <user-name-shared/non-required>
Password: [shared separately]

docker pull appsentinels/front-proxy:latest
docker pull appsentinels/controller:latest

The above commands will not be needed if docker-compose is used to pull the images (via pull option).

2. pull then environment and config files for the docker images
git clone git@github.com:appsentinels/deployment

3. The monolith directory has following structure
./docker-compose-production.yaml
./env
./env/env-envoy.txt
./env/env.txt

4. docker-compose
Use docker-compose version 1.28.6 which has all the fixes related to environment variables.
sudo curl -L "https://github.com/docker/compose/releases/download/1.28.6/docker-compose-$(uname -s)-$(uname -m)" -o /usr/bin/docker-compose

Introduction
============
   For monolith applications we run two dockers front-proxy and opc (onprem-controller). The packet path is as below
   The following is the packet path
                                  api interception                    forwarded after inspection
               external GW/Client <---------------> front-proxy/envoy <------------------------> application
                                                          | 
                                                          |   (authorization/logs request to opc)
                                                          |
                                                           opc <--------------> Appsentinels-saas-server/pii-server

  These dockers can run in a single vm as containers sharing a docker-network or run on different docker-networks or different vm's/hosts. The following are the basic requirements of connectivity/reachability : 
1. front-proxy reachability to application, in case of name of application provided (instead of ip) -- either running on same docker-network or add entry for extra_host (with application name and ip mapping) or resolvable via dns servers
2. front-proxy reachability to opc 
3. opc reachability to the saas-cloud


Configuration file changes
==========================
1. env-envoy.txt Mandatory parameters
   ----------------------------------
	ENVOY_SERVICE_NAME - the name or ip of the application being protected.
	ENVOY_SERVICE_PORT - the port on which the application being protected is listening.
	ENVOY_EXTERNAL_DATA_LISTENING_PORT - the port on which the external router/gw sends the traffic.
e.g.
	ENVOY_SERVICE_NAME=my-shop
	ENVOY_SERVICE_PORT=8080
	ENVOY_EXTERNAL_DATA_LISTENING_PORT=8000

2. env.txt Mandatory parameters
   ----------------------------
	SAAS_API_KEY_VALUE & PII_API_KEY_VALUES available on appsentinels portal. Customer support teams will help retrieve this
	APPLICATION_INFO - name of the application which you want to be displayed on UI
e.g.
	SAAS_API_KEY_VALUE=7Rw9fvA862aOu9cxwCiH3qpBbbLHzN1w
	PII_API_KEY_VALUE=7Rw9fvA862aOu9cxwCiH3qpBbbLHzN1w
	APPLICATION_INFO=Shopping

e.g.
3. env-envoy.txt Optional Parameters
   ----------------------------------
	ENVOY_AUTH_REQUEST_TIMEOUT - the maximum acceptable latency
	ENVOY_FAILURE_MODE_ALLOW - allow/disallow the traffic in case the controller is unavailable due to any reason.
	ENVOY_UPSTREAM_SERVICE_CONNECT_TIMEOUT - maximum time for which the proxy should wait for service/application to respond.
4. env.txt and  env-envoy.txt Advanced Paramters
   ---------------------------------------------
	Rest of the paramaters are advanced parameters and will not need tuning. For special needs reach out to customer support team.

Meeting the requirements of network connectivity
================================================
Default: front-proxy and opc are running on same docker-network (name of network onprem-mesh). Only change required will be for reacability of the application from this docker network (either via providing entry in extra_hosts: or direct-ip instead of name in ENVOY_SERVICE_NAME or via dns entries)

1. front-proxy reachability to application (only in case name of service is provided instead of ip). Options are (options are provided in commented in docker-compose.yaml)
	a. update the ip field in extra_host field in front-service section of docker-compose (Default Config).
	b. update the dns ip's which can be used for name resolution of the application.
	c. if the application has docker form factor can be run on same docker network as front-proxy and opc (or the other way). networks field in docker-compose will have to updated.
	c. use the network_mode as "host" of docker networks in which case it used host dns servers for name resolution. In this case docker internal network cannot connect. So all entries related to section "networks" need to removed from docker-compose

2. front-proxy reachability to opc. front-proxy communicated with opc over 3 ports ENVOY_AUTHZ_SERVICE_PORT (9002), ENVOY_ACCESS_LOG_SERVICE_PORT (9003), ENVOY_METRICS_SERVICE_PORT (9005). Options are
	a. (Default) they run on same docker-network (onprem-mesh). No changes required (optionally remove the external port mapping of opc service ports to reduce the attack surface i.e the ports mapping is removed from ports onprem_controller section)
	b. front-proxy and opc run on different vm's/hosts. Following are the options (options are provided in commented in docker-compose.yaml)
		i. update extra_hosts in front-service with the ip like. e.g. "${ENVOY_ON_PREM_CONTROLLER}:192.168.56.102"
		ii. update the dns ip's to provide the reachability
                iii. use the network_mode as "host" of docker networks in which case it used host dns servers for name resolution. In this case docker internal network cannot connect. So all entries related to section "networks" need to be removed from docker-compose.
		
Setting up and Launching the containers
=======================================
1. setup the syslogs for containers
   -------------------------------
./utils/set-syslog.sh
	sets up to custom rules to redirect container syslogs to (by default to /var/log/appsentinels/ and creates the directory appsentinels inside /var/log on host)
	configures logroatate for log file rotation
2. launching the containers
   ------------------------
/usr/bin/docker-compose -f docker-compose.yaml --env-file env/env-envoy.txt pull && docker-compose -f docker-compose.yaml --env=env/env-envoy.txt up -d

Verifying if all is good
========================
0.  check health-stats on on-boarding stats on ui
    ---------------------------------------------

In case of any concerns check the following:

1. dataplane up
   ------------
docker stats 

2. policies downloaded
   ------------------------------------
./utils/dp-command.sh dp-status | jq -- should output build number and policy number

3. basic counters 
   --------------
./dp-commands.sh get-dpdebugstats | jq

advanced debugging
   -----------------
   for advanced debugging reach out to appsentinels customer support team

Advanced Configuration
======================
1. core-setup (in case apport is installed)
   ----------
   ./utils/set-core-config-settings.sh
